import Arrow from "./cells/arrow.js";
import Orientator from "./cells/orientator.js";
export default [
    Arrow,
    Orientator
];